// app/app.config.ts
export default defineAppConfig({
  title: 'My Nuxt 4 + Vuetify App',
  theme: {
    dark: false
  }
})
