<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>

<script setup lang="ts">
// app.vue chỉ dùng NuxtLayout + NuxtPage
</script>